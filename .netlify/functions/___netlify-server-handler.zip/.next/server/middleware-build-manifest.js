globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/35SIwagt30frxC-mV_ggL/_buildManifest.js",
    "static/35SIwagt30frxC-mV_ggL/_ssgManifest.js",
    "static/35SIwagt30frxC-mV_ggL/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/19mx3mg6lkumu.js",
    "static/chunks/27t_qfc-3_lzs.js",
    "static/chunks/2-rtuqsgzmno4.js",
    "static/chunks/turbopack-1otuxod_nkio7.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
