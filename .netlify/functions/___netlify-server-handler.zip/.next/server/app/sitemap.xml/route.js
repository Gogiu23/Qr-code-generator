var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__0cz50wv._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_05l5km9.js")
R.m(83345)
module.exports=R.m(83345).exports
